package parent_classes

abstract class AgeAnimal() {
    abstract val maxAge: Int
}