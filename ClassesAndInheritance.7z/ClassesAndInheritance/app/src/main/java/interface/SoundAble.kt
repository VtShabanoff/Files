package `interface`

interface SoundAble {
    fun makeSound()
}